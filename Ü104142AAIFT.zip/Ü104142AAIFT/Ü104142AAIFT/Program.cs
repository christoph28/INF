﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü104142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü104142AAIFT | Kegel | Oberfläche + Volumen

            double Höhe, Radius, Mantellinie, Grundfläche, Mantelfläche, Oberfläche, Volumen;   //double da Gleitkommerzahlen

            Console.WriteLine("xxxKegelxxx");   //Überschift

            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.Write("Geben Sie bitte die Höhe in Meter ein: ");   //Eingabeaufforderung Höhe
            Höhe = Convert.ToDouble(Console.ReadLine());    //Einlesen Höhe
            Console.Write("Geben Sie bitte den Radius in Meter ein: "); //Eingabeaufforderung Radius
            Radius = Convert.ToDouble(Console.ReadLine());  //Einlesen Höhe

            Mantellinie = Math.Sqrt(Math.Pow (Höhe, 2) + Math.Pow(Radius, 2)); //Berechnen Mantellinie
            Grundfläche = Math.PI * Math.Pow(Radius, 2);    //Berechnen Grundfläche
            Mantelfläche = Math.PI * Radius * Mantellinie;  //Berechnen Mantelfläche
            Oberfläche = Grundfläche + Mantelfläche;    //Berechnen Oberfläche
            Volumen = Math.PI / (3) * Math.Pow(Radius, 2) * Höhe;   //Berechnen Volumen

            Console.WriteLine();    //Zeilenabsand (Konsole)

            Console.WriteLine("Die Oberfläche beträgt: " + Oberfläche + "m²");   //Ausgabe Oberfläche
            Console.WriteLine("Das Volumen beträgt: " + Volumen + "m³"); //Ausgabe Volumen

            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
