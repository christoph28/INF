﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü103142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü103142AAIFT | Quader | Volumen + Oberfläche

            double Kantenlänge, Kantenbreite, Kantenhöhe, Volumen, Oberfläche;  //double da Gleitkommerzahlen

            Console.WriteLine("xxxQuaderxxx");  //Überschrift

            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.Write("Geben Sie bitte die Kantenlänge in Meter ein: ");    //Eingabeaufforderung Kantenlänge
            Kantenlänge = Convert.ToDouble(Console.ReadLine()); //Kantenlänge einlesen
            Console.Write("Geben Sie bitte die Kantenbreite in Meter ein: ");   //Eingabeaufforderung Kantenbreite
            Kantenbreite = Convert.ToDouble(Console.ReadLine());    //Kantenbreite einlesen
            Console.Write("Geben Sie bitte die Kantenhöhe in Meter ein: ");     //Eingabeaufforderung Kantenhöhe
            Kantenhöhe = Convert.ToDouble(Console.ReadLine());  //Kantenhöhe einlesen

            Oberfläche = 2 * (Kantenlänge * Kantenbreite) + 2 * (Kantenlänge * Kantenhöhe) + 2 * (Kantenbreite * Kantenhöhe);   //Berechnen Oberfläche
            Volumen = Kantenlänge * Kantenbreite * Kantenhöhe;  //Berechnen Volumen
            
            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.WriteLine("Die Oberfläche beträgt: " + Oberfläche + "m²");  //Ausgabe Oberfläche
            Console.WriteLine("Das Volumen beträgt: " + Volumen + "m³");    //Ausgabe Volumen

            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
