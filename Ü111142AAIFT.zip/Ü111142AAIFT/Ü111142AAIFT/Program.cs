﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü111142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü111142AAIFT | Rechteck | Fläche + Umfang | Verzweigung

            double Länge, Breite, Fläche, Umfang;   //Double da Gleitkommerzahlen darstellung

            Console.WriteLine("xxxRechteckxxx");    //Überschrift

            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.Write("Geben Sie bitte die Länge in Meter ein: ");  //Aufforderung für Länge
            Länge = Convert.ToDouble(Console.ReadLine());    //Einlesen Länge

            if (Länge > 0)  //Überprüft die Sinnhaftigkeit der Längen Eingabe (Ob die Länge größer als 0 ist)
            {
                Console.Write("Geben Sie Bitte die Breite in Meter ein: "); //Aufforderung für Breite
                Breite = Convert.ToDouble(Console.ReadLine());   //Einlesen Breite

                if (Breite > 0) //Überprüft die Sinnhaftigkeit der Breiten Eingabe (Ob die Breite größer als 0 ist)
                {
                    Fläche = Länge * Breite;    //Berechnung Fläche
                    Umfang = 2 * Länge + 2 * Breite;    //Berechnung Umfang

                    Console.WriteLine();    //Zeilenabstand (Konsole)

                    Console.WriteLine("Die Fläche beträgt: " + Fläche + "m²"); //Ausgabe Fläche
                    Console.WriteLine("Der Umfang beträgt: " + Umfang + "m");  //Ausgabe Umfang

                }
                else   //Gibt Fehlermeldung aus wenn die Sinnhaftigkeit von der Breite nicht gegeben ist
                {
                    Console.WriteLine();    //Zeilenabstand (Konsole)
                    Console.WriteLine("Die Beite muss über 0 sein");    //Fehlermeldung Breite
                }
            }
            else    //Gibt Fehlermeldung aus wenn die Sinnhaftigkeit von der Länge nicht gegeben ist
            {
                Console.WriteLine();    //Zeilenabstand (Konsole)
                Console.WriteLine("Die Länge muss über 0 sein");    //Fehlermeldung Länge
            }

            Console.ReadLine(); //Hält die Konsole offen;
        }
    }
}
