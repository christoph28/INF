﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü116142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü116 | Dreiecksbestimmung

            double SeiteA, SeiteB, SeiteC;  //Double wegen Kommerdarstellung

            Console.WriteLine("Deiecksbestimmung"); //Ausgabe Überschirft

            Console.Write("\nGeben Sie bitte die Seite A in Meter ein: ");  //Eingabeaufforderung der Variable "SeiteA" (\n = Zeilenabstand in der Konsole)
            SeiteA = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteA"

            if (SeiteA <= 0)    //Überprüft ob die Variable "SeiteA" über 0 liegt
            {
                Console.WriteLine("\nDie Seite A kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
            }
            else    //Wenn Variable "SeiteA" über 0 liegt
            {
                Console.Write("Geben Sie bitte die Seite B in Meter ein: ");    //Eingabeaufforderung der Variable "SeiteB"
                SeiteB = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteB"

                if (SeiteB <= 0)    //Überprüft ob die Variable "SeiteB" über 0 liegt
                {
                    Console.WriteLine("\nDie Seite B kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
                }
                else    //Wenn Variable "SeiteB" über 0 liegt
                {
                    Console.Write("Geben Sie bitte die Seite C in Meter ein: ");    //Eingabeaufforderung der Variable "SeiteC"
                    SeiteC = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteB"

                    if (SeiteC <= 0)    //Überprüft ob die Variable "SeiteC" über 0 liegt
                    {
                        Console.WriteLine("\nDie Seite C kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
                    }
                    else
                    {
                        if (SeiteA + SeiteB <= SeiteC || SeiteA + SeiteC <= SeiteB || SeiteB + SeiteC <= SeiteA)    //Überprüft ob es sich bei den Eingaben um ein Dreieck handelt
                        {
                            Console.WriteLine("\nHierbei handelt es sich um kein Dreieck"); //Ausgabe Felermelung (\n = Zeilenabstand in der Konsole)
                        }
                        else    //Wenn es sich bei den Eingaben um ein Dreieck handelt
                        {
                            if (SeiteA == SeiteB && SeiteB == SeiteC)   //Überprüft ob es sich bei den Eingaben um ein gleichseitiges Dreieck handelt
                            {
                                Console.WriteLine("\nHierbei handelt es sich um ein gleichseitiges Dreieck");   //Ausgabe gleichseitiges Dreieck
                            }
                            else    //Wenn es sich um kein gleichseitiges Dreieck handelt
                            {
                                if (SeiteA == SeiteB || SeiteA == SeiteC || SeiteB == SeiteC)   //Überprüft ob es sich bei den Eingaben um ein gleichschenkeliges Dreieck handelt
                                {
                                    if (Math.Pow(SeiteA, 2) + Math.Pow(SeiteB, 2) == Math.Pow(SeiteC, 2) || Math.Pow(SeiteA, 2) + Math.Pow(SeiteC, 2) == Math.Pow(SeiteB, 2) || Math.Pow(SeiteB, 2) + Math.Pow(SeiteC, 2) == Math.Pow(SeiteA, 2))   //Überprüft ob es sich bei den Eingaben um ein gleichseitiges rechtwinkeliges Dreieck handelt
                                    {
                                        Console.WriteLine("\nHierbei handelt es sich um ein gleichschenkliges rechtwinkeliges Dreieck");    //Ausgabe gleichschenkeliges rechtwinkeliges Dreieck
                                    }
                                    else    //Wenn es sich nicht um ein gleichschenkeliges rechtwinkeliges Dreieck handelt
                                    {
                                        Console.WriteLine("\nHierbei handelt es sich um ein gleichschenkliges Dreieck");    //Ausgabe gleichschenkeliges Dreieck
                                    }
                                }
                                else    //Wenn es sich nicht um ein gleichschenkeliges Dreieck handelt
                                {
                                    if (Math.Pow(SeiteA, 2) + Math.Pow(SeiteB, 2) == Math.Pow(SeiteC, 2) || Math.Pow(SeiteA, 2) + Math.Pow(SeiteC, 2) == Math.Pow(SeiteB, 2) || Math.Pow(SeiteB, 2) + Math.Pow(SeiteC, 2) == Math.Pow(SeiteA, 2))   //Überprüft ob es sich bei den Eingaben um ein rechtwinkeliges Dreieck handelt
                                    {
                                        Console.WriteLine("\nHierbei handelt es sich um ein rechtwinkeliges Dreieck");  //Ausgabe rechtwinkeliges Dreieck
                                    }
                                    else    //Wenn es sich nicht um ein rechtwinkeliges Dreieck handelt
                                    {
                                        Console.WriteLine("\nHierbei handelt es sich um ein allgemeines Dreieck");  //Ausgabe allgemeines Dreieck
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
