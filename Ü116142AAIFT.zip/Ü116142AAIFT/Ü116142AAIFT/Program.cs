﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü116142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz, Mirja Görtemöller | Ü116 | Dreiecksbestimmung

            double SeiteA, SeiteB, SeiteC;

            Console.WriteLine("Deiecksbestimmung");

            Console.WriteLine();

            Console.Write("Geben Sie bitte die Seite A in Meter ein: ");
            SeiteA = Convert.ToDouble(Console.ReadLine());

            if (SeiteA <= 0)
            {
                Console.WriteLine();

                Console.WriteLine("Die Seite A kann nicht kleiner als 0 sein");
            }
            else
            {
                Console.Write("Geben Sie bitte die Seite B in Meter ein: ");
                SeiteB = Convert.ToDouble(Console.ReadLine());

                if (SeiteB <= 0)
                {
                    Console.WriteLine();

                    Console.WriteLine("Die Seite B kann nicht kleiner als 0 sein");
                }
                else
                {
                    Console.Write("Geben Sie bitte die Seite C in Meter ein: ");
                    SeiteC = Convert.ToDouble(Console.ReadLine());

                    Console.WriteLine();

                    if (SeiteC <= 0)
                    {
                        Console.WriteLine("Die Seite C kann nicht kleiner als 0 sein");
                    }
                    else
                    {
                        if (SeiteA + SeiteB <= SeiteC || SeiteA + SeiteC <= SeiteB || SeiteB + SeiteC <= SeiteA)
                        {
                            Console.WriteLine("Hierbei handelt es sich um kein Dreieck");
                        }
                        else
                        {
                            if (SeiteA == SeiteB && SeiteB == SeiteC)
                            {
                                Console.WriteLine("Hierbei handelt es sich um ein Gleichseitig Dreieck");
                            }
                            else
                            {
                                if (SeiteA == SeiteB || SeiteA == SeiteC || SeiteB == SeiteC)
                                {
                                    if (SeiteA * SeiteA + SeiteB * SeiteB == SeiteC * SeiteC || SeiteA * SeiteA + SeiteC * SeiteC == SeiteB * SeiteB || SeiteB * SeiteB + SeiteC * SeiteC == SeiteA * SeiteA)
                                    {
                                        Console.WriteLine("Hierbei handelt es sich um ein Gleichschenkliges rechtwinkeliges Dreieck");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Hierbei handelt es sich um ein Gleichschenkliges Dreieck");
                                    }
                                }
                                else
                                {
                                    if (SeiteA * SeiteA + SeiteB * SeiteB == SeiteC * SeiteC || SeiteA * SeiteA + SeiteC * SeiteC == SeiteB * SeiteB || SeiteB * SeiteB + SeiteC * SeiteC == SeiteA * SeiteA)
                                    {
                                        Console.WriteLine("Hierbei handelt es sich um ein Rechtwinkeliges Dreieck");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Hierbei handelt es sich um ein Allgemeines Dreieck");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
