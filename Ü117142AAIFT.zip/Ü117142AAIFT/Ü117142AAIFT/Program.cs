﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü117142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü117 | Temperatur Rechner SC

            double Temperatur, Kelvin, Fahrenheit, Réaumur, Rankine;  //Double wegen Kommerdarstellung
            char Auswahl;   //Char für 1 Buchstaben darstellung

            Console.WriteLine("Temperatur Rechner SC\n");   //Ausgabe Überschirft

            Console.Write("Geben Sie bitte die Temperatur (unter 1000°C) in °C ein: "); //Eingabeaufforderung der Variable "Temperatur"
            Temperatur = Convert.ToDouble(Console.ReadLine());  //Variable Einlesen

            Console.WriteLine();    //Zeihlenabstand in der Konsole

            if (Temperatur < -273.15)   //Überprüft ob die Temperatur unter -273,15°C liegt
            {
                Console.WriteLine("Die Temperatur kann nicht unter -273.15 grad liegen");   //Fehlermeldung
            }
            else if (Temperatur >= 1000)    //Wenn Temperatur über -273,15°C liegt. Überprüft ob die Temperatur über 1000°C liegt
            {
                Console.WriteLine("Die Temperatur draf nicht über 1000 grad liegen");   //Fehlermeldung
            }
            else    //Wenn Temperatur unter 1000°C liegt
            {
                Console.Write("In welche Einheit ((F)ahrenheit, (K)elvin, (R)éaumur, R(A)nkine) wollen Sie umrechnen?: ");  //Eingabeaufforderung der Variable "Auswahl"
                Auswahl = Convert.ToChar(Console.ReadLine());   //Variable Einlesen
                Auswahl = Char.ToUpper(Auswahl);    //Eingabe in Variable Auswahl wird groß geschrieben

                Console.WriteLine();    //Zeihlenabstand in der Konsole

                switch (Auswahl)    //Auswahl mehrerer Ausgaben (Cases)
                {
                    default:    //Wenn keine der Eingaben in "Auswahl" vorhanden ist
                        Console.Write("Der Angegebene Buchstabe ist nicht erlaubt.");   //Fehlermeldung
                        break;  //Endet den Case

                    case 'F':   //Wenn "F" eingegeben wurde
                        Fahrenheit = Temperatur * 1.8 + 32;  //Berechung von Fahrenheit 
                        Console.WriteLine("Die Temperatur in Fahrenheit beträgt: " + Fahrenheit + "°Fahrenheit"); //Fahrenheit Ausgeben
                        break;  //Endet den Case

                    case 'K':   //Wenn "K" eingegeben wurde
                        Kelvin = Temperatur + 273.15;    //Berrechnung von Kelvin
                        Console.WriteLine("Die Temperatur in Kelvin beträgt: " + Kelvin + "Kelvin");  //Kelvin Ausgeben
                        break;  //Endet den Case

                    case 'R':   //Wenn "R" eingegeben wurde
                        Réaumur = Temperatur * 0.8;   //Berechung von Réaumur
                        Console.WriteLine("Die Temperatur in Réaumur beträgt: " + Réaumur + "°Réaumur");    //Réaumur Ausgeben
                        break;  //Endet den Case

                    case 'A':   //Wenn "A" eingegeben wurde
                        Rankine = Temperatur * 1.8 + 491.67;  //Berechnung von Rankine
                        Console.WriteLine("Die Temperatur in Rankine beträgt: " + Rankine + "°Ra");   //Rankine Ausgeben
                        break;  //Endet den Case
                }
            }
            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
