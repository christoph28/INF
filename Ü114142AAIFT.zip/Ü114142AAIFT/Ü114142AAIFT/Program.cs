﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü114142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü104142AAIFT | Kegel | Oberfläche + Volumen | Verzweigung

            double Höhe, Radius, Mantellinie, Grundfläche, Mantelfläche, Oberfläche, Volumen;   //double da Gleitkommerzahlen

            Console.WriteLine("xxxKegelxxx");   //Überschift

            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.Write("Geben Sie bitte die Höhe in Meter ein: ");   //Eingabeaufforderung Höhe
            Höhe = Convert.ToDouble(Console.ReadLine());    //Einlesen Höhe

            if (Höhe > 0)    //Überprüft die Sinnhaftigkeit der Höhen Eingabe (Ob die Höhe größer als 0 ist)
            {
                Console.Write("Geben Sie bitte den Radius in Meter ein: "); //Eingabeaufforderung Radius
                Radius = Convert.ToDouble(Console.ReadLine());  //Einlesen Höhe

                if (Radius > 0) //Überprüft die Sinnhaftigkeit der Radius Eingabe (Ob der Radius größer als 0 ist)
                {
                    Mantellinie = Math.Sqrt(Math.Pow(Höhe, 2) + Math.Pow(Radius, 2)); //Berechnen Mantellinie
                    Grundfläche = Math.PI * Math.Pow(Radius, 2);    //Berechnen Grundfläche
                    Mantelfläche = Math.PI * Radius * Mantellinie;  //Berechnen Mantelfläche
                    Oberfläche = Grundfläche + Mantelfläche;    //Berechnen Oberfläche
                    Volumen = Math.PI / (3) * Math.Pow(Radius, 2) * Höhe;   //Berechnen Volumen

                    Console.WriteLine();    //Zeilenabsand (Konsole)

                    Console.WriteLine("Die Oberfläche beträgt: " + Oberfläche + "m²");   //Ausgabe Oberfläche
                    Console.WriteLine("Das Volumen beträgt: " + Volumen + "m³"); //Ausgabe Volumen
                }
                else    //Gibt Fehlermeldung aus wenn die Sinnhaftigkeit von dem Radius nicht gegeben ist
                {
                    Console.WriteLine();    //Zeilenabsand (Konsole)
                    Console.WriteLine("Der Radius muss über 0 sein");   //Fehlermeldung Radius
                }
            }
            else    //Gibt Fehlermeldung aus wenn die Sinnhaftigkeit von der Höhe nicht gegeben ist
            {
                Console.WriteLine();    //Zeilenabsand (Konsole)
                Console.WriteLine("Die Höhe muss über 0 sein"); //Fehlermeldung Höhe
            }

            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
