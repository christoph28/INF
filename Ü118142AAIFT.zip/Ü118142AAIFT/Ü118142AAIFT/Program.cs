﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü118142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü118 | Flächenauswahl
            
            double SeiteA, SeiteB, SeiteC, SeiteD, Fläche, Umfang;  //Double wegen Kommerdarstellung
            char Auswahl;   //Char für 1 Buchstaben darstellung

            Console.WriteLine("Flächenauswahl");  //Ausgabe Überschirft
            Console.Write("\nWählen Sie eine von diesen geometrischen Figuren Rechteck(R), Dreieck(D), Kreis(K), Kreisring(I): ");  //Eingabeaufforderung der Variable "Auswahl"
            Auswahl = Convert.ToChar(Console.ReadLine());   //Variable Einlesen
            Auswahl = Char.ToUpper(Auswahl);    //Eingabe der Variable "Auswahl" wird groß geschrieben

            switch (Auswahl)    //Auswahl mehrerer Ausgaben (Cases)
            {
                default:    //Wenn keine der Eingaben in "Auswahl" vorhanden ist
                    Console.WriteLine("\nDer Angegebene Buchstabe " + Auswahl + " ist nicht erlaubt!"); //Fehlermeldung
                    break;  //Endet den Case

                case 'R':   //Wenn "R" eingegeben wurde
                    Console.Write("\nGeben Sie bitte die Seite A ein: ");   //Eingabeaufforderung "SeiteA"
                    SeiteA = Convert.ToDouble(Console.ReadLine());  //"SeiteA" einlesen

                    if (SeiteA <= 0)    //Überprüfung von "SeiteA" auf unter oder gleich 0
                    {
                        Console.WriteLine("\nDie Seite A kann nicht 0 oder kleiner sein");  //Fehlermeldung
                    }
                    else    //Wenn "SeiteA" über 0 ist
                    {
                        Console.Write("Geben Sie bitte die Seite B ein: "); //Eingabeaufforderung "SeiteB"
                        SeiteB = Convert.ToDouble(Console.ReadLine());  //"SeiteB" einlesen
                        if (SeiteB <= 0)    //Überprüfung von "SeiteB" auf unter oder gleich 0
                        {
                            Console.WriteLine("\nDie Seite B kann nicht 0 oder kleiner sein");  //Fehlermeldung
                        }
                        else    //Wenn "SeiteB" über 0 ist
                        {
                            Umfang = 2 * SeiteA + 2 * SeiteB;   //Umfang berechnen
                            Fläche = SeiteA * SeiteB;   //Fläche berechnen

                            Console.WriteLine("\nDer Umfang beträgt: " + Math.Round(Umfang, 2));    //Umfang gerundet ausgeben
                            Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                        }
                    }
                    break;  //Endet den Case

                case 'D':   //Wenn "D" eingegeben wurde
                    Console.WriteLine("\nGeben Sie die Längste Seite bitte möglichst genau an");  //Aufforderung ausgeben

                    Console.Write("\nGeben Sie bitte die Seite A in Meter ein: ");  //Eingabeaufforderung der Variable "SeiteA" (\n = Zeilenabstand in der Konsole)
                    SeiteA = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteA"

                    if (SeiteA <= 0)    //Überprüft ob die Variable "SeiteA" über 0 liegt
                    {
                        Console.WriteLine("\nDie Seite A kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
                    }
                    else    //Wenn Variable "SeiteA" über 0 liegt
                    {
                        Console.Write("Geben Sie bitte die Seite B in Meter ein: ");    //Eingabeaufforderung der Variable "SeiteB"
                        SeiteB = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteB"

                        if (SeiteB <= 0)    //Überprüft ob die Variable "SeiteB" über 0 liegt
                        {
                            Console.WriteLine("\nDie Seite B kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
                        }
                        else    //Wenn Variable "SeiteB" über 0 liegt
                        {
                            Console.Write("Geben Sie bitte die Seite C in Meter ein: ");    //Eingabeaufforderung der Variable "SeiteC"
                            SeiteC = Convert.ToDouble(Console.ReadLine());  //Einlesen der Variable "SeiteB"

                            if (SeiteC <= 0)    //Überprüft ob die Variable "SeiteC" über 0 liegt
                            {
                                Console.WriteLine("\nDie Seite C kann nicht kleiner als 0 sein");   //Ausgabe Fehlermeldung
                            }
                            else
                            {
                                if (SeiteA + SeiteB <= SeiteC || SeiteA + SeiteC <= SeiteB || SeiteB + SeiteC <= SeiteA)    //Überprüft ob es sich bei den Eingaben um ein Dreieck handelt
                                {
                                    Console.WriteLine("\nHierbei handelt es sich um kein Dreieck"); //Ausgabe Felermelung (\n = Zeilenabstand in der Konsole)
                                }
                                else    //Wenn es sich bei den Eingaben um ein Dreieck handelt
                                {
                                    if (SeiteA == SeiteB && SeiteB == SeiteC)   //Überprüft ob es sich bei den Eingaben um ein gleichseitiges Dreieck handelt
                                    {
                                        Umfang = SeiteA + SeiteB + SeiteC;  //Umfang berechnen
                                        Fläche = (Math.Sqrt(3) / 4) * Math.Pow(SeiteA, 2);  //Fläche berechnen

                                        Console.WriteLine("\nHierbei handelt es sich um ein gleichseitiges Dreieck\n");   //Ausgabe gleichseitiges Dreieck
                                        Console.WriteLine("Der Umfang beträgt: " + Math.Round(Umfang, 2));  //Umfang gerundet ausgeben
                                        Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                                    }
                                    else    //Wenn es sich um kein gleichseitiges Dreieck handelt
                                    {
                                        if (SeiteA == SeiteB || SeiteA == SeiteC || SeiteB == SeiteC)   //Überprüft ob es sich bei den Eingaben um ein gleichschenkeliges Dreieck handelt
                                        {
                                            if (Math.Abs(Math.Pow(SeiteA, 2) + Math.Pow(SeiteB, 2) - Math.Pow(SeiteC, 2)) < Math.Pow(SeiteC, 2) * 0.01 || Math.Abs(Math.Pow(SeiteA, 2) + Math.Pow(SeiteC, 2) - Math.Pow(SeiteB, 2)) < Math.Pow(SeiteC, 2) * 0.01 || Math.Abs(Math.Pow(SeiteB, 2) + Math.Pow(SeiteC, 2) - Math.Pow(SeiteA, 2)) < Math.Pow(SeiteA, 2) * 0.01)   //Überprüft ob es sich bei den Eingaben um ein gleichseitiges rechtwinkeliges Dreieck handelt mit 1% Toleranz (Math.Abs -> Macht aus Negativ Positiv (-3 -> 3, 5 -> 5))
                                            {
                                                SeiteD = Math.Min(Math.Min(SeiteA, SeiteB), SeiteC);    //Bestimmt die kleinste Seite
                                                Umfang = SeiteA + SeiteB + SeiteC;  //Umfang berechnen
                                                Fläche = Math.Pow(SeiteD, 2) / 4;   //Fläche berechnen

                                                Console.WriteLine("\nHierbei handelt es sich um ein gleichschenkliges rechtwinkeliges Dreieck\n");    //Ausgabe gleichschenkeliges rechtwinkeliges Dreieck
                                                Console.WriteLine("Der Umfang beträgt: " + Math.Round(Umfang, 2));  //Umfang gerundet ausgeben
                                                Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                                            }
                                            else    //Wenn es sich nicht um ein gleichschenkeliges Dreieck handelt
                                            {
                                                Umfang = SeiteA + SeiteB + SeiteC;  //Umfang berechnen
                                                Fläche = (Math.Max(Math.Max(SeiteA, SeiteB), SeiteC) / 4) * (Math.Sqrt(4 * Math.Pow(Math.Min(Math.Min(SeiteA, SeiteB), SeiteC), 2) - Math.Pow(Math.Max(Math.Max(SeiteA, SeiteB), SeiteC), 2)));

                                                Console.WriteLine("\nHierbei handelt es sich um ein gleichschenkliges Dreieck\n");    //Ausgabe gleichschenkeliges Dreieck                                     
                                                Console.WriteLine("Der Umfang beträgt: " + Math.Round(Umfang, 2));  //Umfang gerundet ausgeben
                                                Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                                            }
                                        }
                                        else    //Wenn es sich nicht um ein gleichschenkeliges Dreieck handelt
                                        {
                                            if (Math.Abs(Math.Pow(SeiteA, 2) + Math.Pow(SeiteB, 2) - Math.Pow(SeiteC, 2)) < Math.Pow(SeiteC, 2) * 0.01 || Math.Abs(Math.Pow(SeiteA, 2) + Math.Pow(SeiteC, 2) - Math.Pow(SeiteB, 2)) < Math.Pow(SeiteC, 2) * 0.01 || Math.Abs(Math.Pow(SeiteB, 2) + Math.Pow(SeiteC, 2) - Math.Pow(SeiteA, 2)) < Math.Pow(SeiteA, 2) * 0.01)   //Überprüft ob es sich bei den Eingaben um ein rechtwinkeliges Dreieck handelt mit 1% Toleranz
                                            {
                                                Umfang = SeiteA + SeiteB + SeiteC;  //Umfang berechnen
                                                Fläche = (Math.Min(Math.Min(SeiteA, SeiteB), SeiteC) * (Umfang - (Math.Min(Math.Min(SeiteA, SeiteB), SeiteC) + Math.Max(Math.Max(SeiteA, SeiteB), SeiteC)))) / 2;   //Fläche berechnen durch bestimmung der Katheten

                                                Console.WriteLine("\nHierbei handelt es sich um ein rechtwinkeliges Dreieck\n");  //Ausgabe rechtwinkeliges Dreieck
                                                Console.WriteLine("Der Umfang beträgt: " + Math.Round(Umfang, 2));  //Umfang gerundet ausgeben
                                                Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                                            }
                                            else    //Wenn es sich nicht um ein rechtwinkeliges Dreieck handelt
                                            {
                                                Console.WriteLine("\nHierbei handelt es sich um ein allgemeines Dreieck");  //Ausgabe allgemeines Dreieck
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;  //Endet den Case
                    
                case 'K':   //Wenn "K" eingegeben wurde
                    Console.Write("\nGeben Sie bitte den Radius ein: ");    //Eingabeaufforderung "Radius"
                    SeiteA = Convert.ToDouble(Console.ReadLine());  //Radius einlesen

                    if (SeiteA <= 0)    //Überprüft ob "Radius" kleine oder gleich 0 ist
                    {
                        Console.WriteLine("\nDer Radius kann nicht 0 oder kleiner sein!");  //Fehlermeldung
                    }
                    else    //Wenn "Radius" größer als 0 ist
                    {
                        Umfang = SeiteA * 2 * Math.PI;  //Umfang berechnen
                        Fläche = Math.Pow(SeiteA, 2) * Math.PI; //Fläche berechnen

                        Console.WriteLine("\nDer Umfang beträgt: " + Math.Round(Umfang, 2));    //Umfang gerundet ausgeben
                        Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                    }
                    break;  //Endet den Case

                case 'I':   //Wenn "I" eingegeben wurde
                    Console.Write("\nGeben Sie bitte den inneren Radius ein: ");    //Eingabeaufforderung "Innerer Radius"
                    SeiteA = Convert.ToDouble(Console.ReadLine());  //"Innerer Radius" einlesen
                    if (SeiteA <= 0)    //Überprüft ob "Innerer Radius" kleiner oder gleich 0 ist
                    {
                        Console.WriteLine("\nDer Radius kann nicht 0 oder kleiner sein!");  //Fehlermeldung
                    }
                    else    //Wenn "Innerer Radius" größer als 0 ist
                    {
                        Console.Write("Geben Sie bitte den äußeren Radius ein: ");  //Eingabeaufforderung "Äußerer Radius"
                        SeiteB = Convert.ToDouble(Console.ReadLine());  //"Äußerer Radius" einlesen
                        if (SeiteB <=0)  //Überprüft ob "Äußerer Radius" kleiner oder gleich 0 ist
                        {
                            Console.WriteLine("\nDer Radius kann nicht 0 oder kleiner sein!");  //Fehlermeldung
                        }
                        else    //Wenn "Äußerer Radius" größer als 0 ist
                        {
                            SeiteC = 2 * Math.PI * SeiteA;  //Innerer Umfang berechnen
                            SeiteD = 2 * Math.PI * SeiteB;  //Äußerer Umfang berechnen
                            Umfang = SeiteC + SeiteD;   //Gesamt Umfang berechnen
                            Fläche = (Math.Pow(SeiteB, 2) * Math.PI) - (Math.Pow(SeiteA, 2) * Math.PI); //Fläche berechnen

                            Console.WriteLine("\nDer innere Umfang beträgt: " + Math.Round(SeiteC, 2)); //Inneren Umfang gerundet ausgeben
                            Console.WriteLine("Der aüßere Umfang beträgt: " + Math.Round(SeiteD, 2));   //Äußerer Umfang gerundet ausgeben
                            Console.WriteLine("\nDer gesamt Umfang beträgt: " + Math.Round(Umfang, 2));    //Gesamt Umfang gerundet ausgeben
                            Console.WriteLine("Die Fläche beträgt: " + Math.Round(Fläche, 2));  //Fläche gerundet ausgeben
                        }
                    }
                    break;  //Endet den Case
            }
            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
