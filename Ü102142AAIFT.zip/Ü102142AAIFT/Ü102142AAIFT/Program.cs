﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü102142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | 102142AAIFT | Kreis | Umfang + Fläche

            double Radius, Fläche, Umfang; //Double da es sich bei Pi um eine Kommerzahl Handelt und damit man Kommerzahlen eingeben kann

            Console.WriteLine("xxxKreisxxx");   //Überschrift

            Console.WriteLine();    //Zeilenabstand (Console)

            Console.Write("Geben Sie Bitte den Radius in Meter ein: "); //Aufforderung für Radius
            Radius = Convert.ToDouble(Console.ReadLine());  //Einlesen Radius
            
            Fläche = Math.PI * Radius * Radius; //Berechnen Fläche
            Umfang = 2 * Math.PI * Radius;  //Berechnen Umfang

            Console.WriteLine();    //Zeilenabstand (Console)

            Console.WriteLine("Die Fläche beträgt:" + Fläche + "m²");  //Ausgeben Fläche
            Console.WriteLine("Der Umfang beträgt:" + Umfang + "m");   //Ausgeben Umfang

            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
