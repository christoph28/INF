﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü115142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {
            //Christoph Kurz | Ü115 | Temperatur Umrechner

            double Fahrenheit, Kelvin, Réaumur, Rankine, Temperatur;    //Double wegen Kommerdarstellung
            char Einheit;   //char wegen Buchstaben eingabe

            Console.WriteLine("Temperatur Rechner");    //Überschrift

            Console.WriteLine();    //Zeilenabstand (Konsole)

            Console.Write("Geben Sie bitte die Temperatur (unter 1000°C) in °C ein: "); //Eingabeaufforderung Temperatur
            Temperatur = Convert.ToDouble(Console.ReadLine());  //Einlesen Temperatur

            Console.WriteLine();    //Zeilenabstand (Konsole)

            if (Temperatur <= 1000 && Temperatur >= -273.15)    //Überprüft die Sinnhaftigkeit der Temperatur Eingabe (Ob die Temperatur zwischen 100 und -273,15 liegt)
            {
                Console.Write("In welche Einheit ((F)ahrenheit, (K)elvin, (R)éaumur, R(A)nkine) wollen Sie umrechnen?: ");  //Eingabeaufforderung Einheit
                Einheit = Convert.ToChar(Console.ReadLine());   //Einlesen Einheit
                Einheit = Char.ToUpper(Einheit);    //Variable "Einheit" wird auf großbuchstaben geändert (Damit man die Eingabe groß und klein schreiben kann)

                Console.WriteLine();    //Zeilenabstand (Konsole)

                if (Einheit == 'F' )    //Überprüft ob die Variable "Einheit" "F" (Fahrenheit) ist
                {
                    Fahrenheit = Temperatur * 1.8 + 32; //Berechnet Fahrenheit
                    Console.WriteLine("Die Temperatur in Fahrenheit beträgt: " + Fahrenheit + "°F");    //Gibt Fahrenheit aus
                }
                else    //Wenn die Variable "Einheit" nicht "F" ist
                {
                    if (Einheit == 'K') //Überprüft ob die Variable "Einheit" "K" (Kelvin) ist
                    {
                        Kelvin = Temperatur + 273.15;   //Berechnet Kelvin
                        Console.WriteLine("Die Temperatur in Kelvin beträgt: " + Kelvin + "K"); //Gibt Kelvin aus
                    }
                    else    //Wenn die Variable "Einheit" nicht "K" ist
                    {
                        if (Einheit == 'R') //Überprüft ob die Variable "Einheit" "R" (Réaumur) ist
                        {
                            Réaumur = Temperatur * 0.8; //Berechnet Réaumur
                            Console.WriteLine("Die Temperatur in Réaumur beträgt: " + Réaumur + "°R");  //Gibt Réaumur aus
                        }
                        else    //Wenn die Variable "Einheit" nicht "R" ist
                        {
                            if (Einheit == 'A') //Überprüft ob die Variable "Einheit" "A" (Rankine) ist
                            {
                                Rankine = Temperatur * 1.8 + 491.67;    //Berechnet Rankine
                                Console.WriteLine("Die Temperatur in Rankine beträgt: " + Rankine + "°Ra"); //Gibt Rankine aus
                            }
                            else    //Wenn die Variable "Einheit" nicht auf eine der Überprüfungen zutrifft
                            {
                                Console.WriteLine("Eingabefehler"); //Gibt Fehlermeldung aus
                            }
                        }
                    }
                }
            }
            else    //Wenn die Variable "Temperatur" nicht zwischen 1000 und -273,15 liegt
            {
                if (Temperatur >= 1000) //Überprüft ob die Variable "Temperatur" über 999 liegt
                {
                    Console.WriteLine("Temperatur darf nicht über 1000°C liegen");  //Gibt Fehlermeldung aus
                }
                else    //Wenn die Variable "Temperatur" nicht über 999 liegt
                {
                    Console.WriteLine("Temperatur darf nicht unter -273,15°C liegen");  //Gibt Fehlermeldung aus
                }
            }
            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
