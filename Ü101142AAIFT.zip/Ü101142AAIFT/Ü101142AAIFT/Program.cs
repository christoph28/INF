﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü101142AAIFT
{
    class Program
    {
        static void Main(string[] args)
        {   
            //Christoph Kurz | Ü101142AAIFT | Rechteck | Fläche + Umfang
            
            double Länge, Breite, Fläche, Umfang;
            
            Console.WriteLine("xxxRechteckxxx");    //Überschrift

            Console.WriteLine();    //Abstand (Zeile)

            Console.Write("Geben Sie bitte die Länge in Meter ein: ");  //Aufforderung für Länge
            Länge = Convert.ToDouble(Console.ReadLine());    //Einlesen Länge
            Console.Write("Geben Sie Bitte die Breite in Meter ein: "); //Aufforderung für Breite
            Breite = Convert.ToDouble(Console.ReadLine());   //Einlesen Breite

            Fläche = Länge * Breite;    //Berechnen Fläche
            Umfang = 2 * Länge + 2 * Breite;    //Berechnen Umfang

            Console.WriteLine();    //Abstand (Zeile)

            Console.WriteLine("Die Fläche beträgt: " + Fläche + "cm²"); //Ausgabe Fläche
            Console.WriteLine("Der Umfang beträgt: " + Umfang + "cm");  //Ausgabe Umfang

            Console.ReadLine(); //Hält die Konsole offen
        }
    }
}
